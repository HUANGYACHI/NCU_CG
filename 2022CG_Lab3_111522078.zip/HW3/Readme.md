# Readme

## 使用 Linux

### 編譯與執行 (cmake)
1. 在 `build` 資料夾裡開終端機
2. 輸入 `make` 編譯
3. 輸入 `./執行檔名稱` 執行程式
    + lab3 輸入 `./HW3 Data/lab3X.in`

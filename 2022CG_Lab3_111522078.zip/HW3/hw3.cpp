#include <GL/glut.h>
#include <GL/gl.h>
#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include "Vector.h"
#include "Mesh.h"
using namespace std;

#define PAUSE printf("Press Enter key to continue..."); fgetc(stdin); 
#define PI 3.1415926

int window;
char mode = 'd';
int tempX = -1;
int tempY = -1;
int polTempX, polTempY;
bool clearVector = 0;
bool polStart = 0;
ifstream ifs;
bool noDraw = 0;
int width = 0;
int height = 0;
Matrix4 transformMatrix = Matrix4::Identity();
float view[4] = { 0.0 };
TrianglesMatrix Triangle;
Matrix4 EM;
Matrix4 PM;
Vector3 eyev;

class NODE {
    public:
        int x;
        int y;
        GLfloat red;
        GLfloat green;
        GLfloat blue;
};

class COLOR {
    public:
        GLfloat red;
        GLfloat green;
        GLfloat blue;
};

NODE temp;
vector<NODE> record;
vector<vector<vector<float>>> objects;
vector<vector<float>> objects2;
vector<float> objects1;
vector<vector<vector<float>>> viewObject;
COLOR ctemp;
vector<COLOR> color;
vector<TrianglesMatrix> Triangles;
vector<TrianglesMatrix> DisplayTriangles;
vector<Vector4> ClipTriangle;
vector<vector<Vector4>> ClipTriangles;

// 即時更新
void timer(int val) {
    glutPostRedisplay();
    glutTimerFunc(30, timer, 0);
}

void drawPoints(int x, int y) {
    glBegin(GL_POINTS);
    glVertex2i(x, 800-y);
    glEnd();   
}

void drawLines(int startX, int startY, int x, int y, GLfloat red, GLfloat green, GLfloat blue) { // 左上00
    //cout << "startX" << startX << " startY" << startY << " x" << x << " y" << y << " " << "\n";
    // 右到左畫線變為左到右
    if (startX > x) {
        swap(startX, x);
        swap(startY, y);
    }
    int a = (y - startY);
    int b = (startX - x);
    //cout << "a" << a << " b" << b << "\n";
    glBegin(GL_POINTS);
    glVertex2i(startX, 800 - startY);
    temp.x = startX;
    temp.y = startY;
    if (mode != 'p' && polStart) {
        temp.red = red;
        temp.green = green;
        temp.blue = blue;
        polStart = 0;
    }
    record.push_back(temp);

    if (startY <= y && abs(a) <= abs(b)) { // 左上右下 0<m<1
        int d = a + b / 2;
        while (startX < x) {
            if (d <= 0) {
                startX++;
                d += a;
            }
            else {
                startX++;
                startY++;
                d += (a + b);
            }
            glVertex2i(startX, 800 - startY);
            temp.x = startX;
            temp.y = startY;
            if (mode != 'p') {
                temp.red = red;
                temp.green = green;
                temp.blue = blue;
            }
            record.push_back(temp);
        }
    }
    else if (startY > y && abs(a) <= abs(b)) { // 右上左下 -1<m<0
        int d = a + b / 2;
        while (startX < x) {
            if (d <= 0) {
                startX++;
                startY--;
                d += (a - b);
            }
            else {
                startX++;
                d += a;
            }
            glVertex2i(startX, 800 - startY);
            temp.x = startX;
            temp.y = startY;
            if (mode != 'p') {
                temp.red = red;
                temp.green = green;
                temp.blue = blue;
            }
            record.push_back(temp);
        }
    }
    else if (startY <= y && abs(a) > abs(b)) { // 左上右下 m>1
        int d = b + a / 2;
        while (startY < y) {
            if (d <= 0) {
                startX++;
                startY++;
                d += (a + b);
            }
            else {
                startY++;
                d += b;
            }
            glVertex2i(startX, 800 - startY);
            temp.x = startX;
            temp.y = startY;
            if (mode != 'p') {
                temp.red = red;
                temp.green = green;
                temp.blue = blue;
            }
            record.push_back(temp);
        }
    }
    else if (startY > y && abs(a) > abs(b)) { // 右上左下 m<-1
        int d =  b + a / 2;
        while (startY >= y) {
            if (d <= 0) {
                startY--;
                d -= b;
            }
            else {
                startX++;
                startY--;
                d += (a - b);
            }
            glVertex2i(startX, 800 - startY);
            temp.x = startX;
            temp.y = startY;
            if (mode != 'p') {
                temp.red = red;
                temp.green = green;
                temp.blue = blue;
            }
            record.push_back(temp);
        }
    }
    
    glEnd();
}

void drawCircles(int centerX, int centerY, int radiusX, int radiusY, GLfloat red, GLfloat green, GLfloat blue) {
    int R = sqrt(pow(radiusX - centerX, 2) + pow(radiusY - centerY, 2));
    int x = 0, y = R;
    int d = 1 - R;
    int incE = 3;
    int incSE = -2 * R + 5;

    glBegin(GL_POINTS);
    glVertex2i(centerX, 800 - (centerY + R));
    temp.x = centerX;
    temp.y = centerY + R;
    temp.red = red;
    temp.green = green;
    temp.blue = blue;
    record.push_back(temp);
    while (x < y) {
        if (d < 0) {
            d += incE;
            incE += 2;
            incSE += 2;
            x++;
        }
        else {
            d += incSE;
            incE += 2;
            incSE += 4;
            x++;
            y--;
        }
        glVertex2i(x + centerX, 800 - (y + centerY));
        temp.x = x + centerX;
        temp.y = y + centerY;
        record.push_back(temp);
        // 畫出另外七區
        glVertex2i(x + centerX, 800 - (-y + centerY));
        temp.x = x + centerX;
        temp.y = -y + centerY;
        record.push_back(temp);
        glVertex2i(y + centerX, 800 - (x + centerY));
        temp.x = y + centerX;
        temp.y = x + centerY;
        record.push_back(temp);
        glVertex2i(y + centerX, 800 - (-x + centerY));
        temp.x = y + centerX;
        temp.y = -x + centerY;
        record.push_back(temp);
        glVertex2i(-x + centerX, 800 - (y + centerY));
        temp.x = -x + centerX;
        temp.y = y + centerY;
        record.push_back(temp);
        glVertex2i(-x + centerX, 800 - (-y + centerY));
        temp.x = -x + centerX;
        temp.y = -y + centerY;
        record.push_back(temp);
        glVertex2i(-y + centerX, 800 - (x + centerY));
        temp.x = -y + centerX;
        temp.y = x + centerY;
        record.push_back(temp);
        glVertex2i(-y + centerX, 800 - (-x + centerY));
        temp.x = -y + centerX;
        temp.y = -x + centerY;
        record.push_back(temp);
    }
    glEnd();
}

void drawLines(int startX, int startY, int x, int y) { // 左上00
    //cout << "startX" << startX << " startY" << startY << " x" << x << " y" << y << " " << "\n";
    // 右到左畫線變為左到右
    if (startX > x) {
        swap(startX, x);
        swap(startY, y);
    }
    int a = (y - startY);
    int b = (startX - x);
    //cout << "a" << a << " b" << b << "\n";
    glBegin(GL_POINTS);
    glVertex2i(startX, startY);
    if (startY <= y && abs(a) <= abs(b)) { // 左上右下 0<m<1
        int d = a + b / 2;
        while (startX < x) {
            if (d <= 0) {
                startX++;
                d += a;
            }
            else {
                startX++;
                startY++;
                d += (a + b);
            }
            glVertex2i(startX, startY);
        }
    }
    else if (startY > y && abs(a) <= abs(b)) { // 右上左下 -1<m<0
        int d = a + b / 2;
        while (startX < x) {
            if (d <= 0) {
                startX++;
                startY--;
                d += (a - b);
            }
            else {
                startX++;
                d += a;
            }
            glVertex2i(startX, startY);
        }
    }
    else if (startY <= y && abs(a) > abs(b)) { // 左上右下 m>1
        int d = b + a / 2;
        while (startY < y) {
            if (d <= 0) {
                startX++;
                startY++;
                d += (a + b);
            }
            else {
                startY++;
                d += b;
            }
            glVertex2i(startX, startY);
        }
    }
    else if (startY > y && abs(a) > abs(b)) { // 右上左下 m<-1
        int d = b + a / 2;
        while (startY >= y) {
            if (d <= 0) {
                startY--;
                d -= b;
            }
            else {
                startX++;
                startY--;
                d += (a - b);
            }
            glVertex2i(startX, startY);
        }
    }
    glEnd();
}

void printMatrix() {
    cout << transformMatrix << endl;
}

// Returns x-value of point of intersection of two lines
int x_intersect(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
    int num = (x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4);
    int den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    return num / den;
}

// Returns y-value of point of intersection of two lines
int y_intersect(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
    int num = (x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4);
    int den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    return num / den;
}

void clip(int polyNum, int polySize, int x1, int y1, int x2, int y2) {
    vector<Vector4> polyPoints;

    for (int i = 0; i < polySize; i++) {
        int k = (i + 1) % polySize;
        int ix = round(ClipTriangles[polyNum][i].x);
        int iy = round(ClipTriangles[polyNum][i].y);
        int kx = round(ClipTriangles[polyNum][k].x);
        int ky = round(ClipTriangles[polyNum][k].y);
        int iPos = (x2 - x1) * (iy - y1) - (y2 - y1) * (ix - x1);
        int kPos = (x2 - x1) * (ky - y1) - (y2 - y1) * (kx - x1);

        // Case 1 : When both points are inside
        if (iPos < 0 && kPos < 0) {
            //Only second point is added
            Vector4 polyPoint(kx, ky, 1, 1);
            polyPoints.push_back(polyPoint);
        }

        // Case 2: When only first point is outside
        else if (iPos >= 0 && kPos < 0) {
            // Point of intersection with edge and the second point is added
            Vector4 polyPoint(x_intersect(x1, y1, x2, y2, ix, iy, kx, ky), y_intersect(x1, y1, x2, y2, ix, iy, kx, ky), 1, 1);
            polyPoints.push_back(polyPoint);

            Vector4 polyPoint2(kx, ky, 1, 1);
            polyPoints.push_back(polyPoint2);
        }

        // Case 3: When only second point is outside
        else if (iPos < 0 && kPos >= 0) {
            //Only point of intersection with edge is added
            Vector4 polyPoint(x_intersect(x1, y1, x2, y2, ix, iy, kx, ky), y_intersect(x1, y1, x2, y2, ix, iy, kx, ky), 1, 1);
            polyPoints.push_back(polyPoint);
        }

        // Case 4: When both points are outside
        else {
            //No points are added
        }
    }

    if (polyPoints.size() == 0) {
        noDraw = 1;
    } else {
        vector<vector<Vector4>>::iterator it = ClipTriangles.begin();
        ClipTriangles.erase(it+polyNum);
        ClipTriangles.insert(it+polyNum, polyPoints);
    }
    
}

void fill(int polyNum, int polySize) {
    int yMin = 800;
    int yMax = 0;
    vector<int> nodes;
    for (int i = 0; i < polySize; i++) {
        if (viewObject[polyNum][1][i] > yMax) {
            yMax = viewObject[polyNum][1][i];
        }
        if (viewObject[polyNum][1][i] < yMin) {
            yMin = viewObject[polyNum][1][i];
        }
    }
    //nodes記與y軸交點
    for (int i = yMin; i < yMax; i++) { //scanline y
        //save nodes
        for (int j = 0; j < polySize; j++) { //edge
            if (viewObject[polyNum][1][j] < i && viewObject[polyNum][1][(j + 1) % polySize] >= i
                || viewObject[polyNum][1][j] >= i && viewObject[polyNum][1][(j + 1) % polySize] < i) {
                nodes.push_back(x_intersect(0, i, 800, i, viewObject[polyNum][0][j], viewObject[polyNum][1][j], viewObject[polyNum][0][(j + 1) % polySize], viewObject[polyNum][1][(j + 1) % polySize]));
            }
        }
        //sort nodes
        sort(nodes.begin(), nodes.end());
        //fill
        for (int k = 0; k < nodes.size(); k += 2) {
            drawLines(nodes[k], i, nodes[k + 1], i);
        }
        nodes.clear();
    }
}

void clip3D(int polyNum, int polySize, int c){
    vector<Vector4> polyPoints3D;

    for (int i = 0; i < polySize; i++) {
        int k = (i + 1) % polySize;
        Vector4 iv = ClipTriangles[polyNum][i];
        Vector4 kv = ClipTriangles[polyNum][k];
        float iPos = 0;
        float kPos = 0;
        switch (c)
        {
            case 1:
                iPos = iv.w + iv.x;
                kPos = kv.w + kv.x;
                break;
            case 2:
                iPos = iv.w - iv.x;
                kPos = kv.w - kv.x;
                break;
            case 3:
                iPos = iv.w + iv.y;
                kPos = kv.w + kv.y;
                break;
            case 4:
                iPos = iv.w - iv.y;
                kPos = kv.w - kv.y;
                break;
            case 5:
                iPos = iv.z;
                kPos = kv.z;
                break;
            case 6:
                iPos = iv.w - iv.z;
                kPos = kv.w - kv.z;
                break;
            default:
                break;
        }

        // Case 1 : When both points are visible
        if (iPos >= 0 && kPos >= 0) {
            //Only second point is added
            Vector4 polyPoint(kv.x, kv.y, kv.z, kv.w);
            polyPoints3D.push_back(polyPoint);
        }

        // Case 2: When only second point is visible
        else if (iPos < 0 && kPos >= 0) {
            // Point of intersection with edge and the second point is added
            float t = iPos / (iPos - kPos);
            Vector4 polyPoint(iv.x + t * (kv.x - iv.x), iv.y + t * (kv.y - iv.y), iv.z + t * (kv.z - iv.z), iv.w + t * (kv.w - iv.w));
            polyPoints3D.push_back(polyPoint);

            Vector4 polyPoint2(kv.x, kv.y, kv.z, kv.w);
            polyPoints3D.push_back(polyPoint2);
        }

        // Case 3: When only first point is visible
        else if (iPos >= 0 && kPos < 0) {
            //Only point of intersection with edge is added
            float t = iPos / (iPos - kPos);
            Vector4 polyPoint(iv.x + t * (kv.x - iv.x), iv.y + t * (kv.y - iv.y), iv.z + t * (kv.z - iv.z), iv.w + t * (kv.w - iv.w));
            polyPoints3D.push_back(polyPoint);
        }

        // Case 4: When both points are unvisible
        else {
            //No points are added
        }

    }

    if (polyPoints3D.size() == 0) {
        noDraw = 1;
    } else {
        vector<vector<Vector4>>::iterator it = ClipTriangles.begin();
        ClipTriangles.erase(it+polyNum);
        ClipTriangles.insert(it+polyNum, polyPoints3D);
    }
}

void readFile() {
    string buffer;

    vector<string> words;
    string word;
    while (getline(ifs, buffer)) {
        cout << buffer << "\n";
        if (buffer.size() == 0) continue;
        if (buffer[0] == '#') continue;
        while (1) {
            if (buffer.substr(0, buffer.find(" ")) != "") {
                words.push_back(buffer.substr(0, buffer.find(" "))); // 從第一個空白分割出左側子字串放入vector
            }
            buffer = buffer.substr(buffer.find(" ") + 1, buffer.length()); // 從第一個空白分割出右側子字串設為buffer

            // 取得最後一個字。最後一個字找不到空白了
            if (buffer.find(" ") == -1) {
                words.push_back(buffer);
                break;
            }
        }
        if (words[0] == "view") { //[1]wxl [2]wxr [3]wyb [4]wyt [5]vxl [6]vxr [7]vyb [8]vyt
            //映射
            //映射後x = ((映射前x - wxl) * (vxr - vxl) / (wxr - wxl)) + vxl
            //映射後y = ((映射前y - wyb) * (vyt - vyb) / (wyt - wyb)) + vyb
            glColor3f(1, 1, 1);
            drawLines(stoi(words[5]), stoi(words[7]), stoi(words[6]), stoi(words[7]));
            drawLines(stoi(words[6]), stoi(words[7]), stoi(words[6]), stoi(words[8]));
            drawLines(stoi(words[6]), stoi(words[8]), stoi(words[5]), stoi(words[8]));
            drawLines(stoi(words[5]), stoi(words[8]), stoi(words[5]), stoi(words[7]));
            glFlush();
            for (int i = 0; i < objects.size(); i++) {
                glColor3f(color[i].red, color[i].green, color[i].blue);
                for (int j = 0; j < objects[i].size(); j++) {
                    viewObject[i][j].clear();
                    for (int k = 0; k < objects[i][j].size(); k++) {
                        if (j == 0) { //x
                            viewObject[i][j].push_back((objects[i][j][k] - stof(words[1])) * (stof(words[6]) - stof(words[5])) / (stof(words[2]) - stof(words[1])) + stof(words[5]));
                        }
                        else if (j == 1) { //y
                            viewObject[i][j].push_back((objects[i][j][k] - stof(words[3])) * (stof(words[8]) - stof(words[7])) / (stof(words[4]) - stof(words[3])) + stof(words[7]));
                        }
                    }
                }
                //clip view邊框逆時針輸入
                clip(i, viewObject[i][0].size(), stoi(words[5]), stoi(words[7]), stoi(words[5]), stoi(words[8]));
                clip(i, viewObject[i][0].size(), stoi(words[5]), stoi(words[8]), stoi(words[6]), stoi(words[8]));
                clip(i, viewObject[i][0].size(), stoi(words[6]), stoi(words[8]), stoi(words[6]), stoi(words[7]));
                clip(i, viewObject[i][0].size(), stoi(words[6]), stoi(words[7]), stoi(words[5]), stoi(words[7]));
                //cout << endl;
                if (noDraw) {
                    noDraw = 0;
                } else {
                    for (int k = 0; k < viewObject[i][0].size(); k++) {
                        int l = (k + 1) % viewObject[i][0].size();
                        drawLines(round(viewObject[i][0][k]), round(viewObject[i][1][k]), round(viewObject[i][0][l]), round(viewObject[i][1][l]));
                    }
                    //fill
                    fill(i, viewObject[i][0].size());
                }
                glFlush();
            }
            PAUSE;
        }
        else if (words[0] == "viewport") { //[1]vxl [2]vxr [3]vyb [4]vyt
            for (int i = 0; i < 4; i++) {
                view[i] = stof(words[i + 1]);
            }
        }
        else if (words[0] == "reset") {
            //clear transformMatrix
            transformMatrix = Matrix4::Identity();
            //printMatrix();
        }
        else if (words[0] == "translate") {
            //移動 +
            Matrix4 tm = Matrix4::Trans(Vector3(stof(words[1]), stof(words[2]), stof(words[3])));
            transformMatrix = tm * transformMatrix;
            printMatrix();
        }
        else if (words[0] == "scale") {
            //縮放 *
            Matrix4 tm = Matrix4::Scale(Vector3(stof(words[1]), stof(words[2]), stof(words[3])));
            transformMatrix = tm * transformMatrix;
            printMatrix();
        }
        else if (words[0] == "rotate") {
            //旋轉
            float rangex = stof(words[1]) * PI / 180;
            float rangey = stof(words[2]) * PI / 180;
            float rangez = stof(words[3]) * PI / 180;
            Matrix4 tmy = Matrix4::RotY(rangey);
            //cout << "range:" << range << " cos:" << cos(range) << " sin:" << sin(range) << endl;
            transformMatrix = tmy * transformMatrix;
            printMatrix();
            Matrix4 tmz = Matrix4::RotZ(rangez);
            transformMatrix = tmz * transformMatrix;
            printMatrix();
            Matrix4 tmx = Matrix4::RotX(rangex);
            transformMatrix = tmx * transformMatrix;
            printMatrix();
        }
        else if (words[0] == "clearData") {
            //清除物件
            objects.clear();
            viewObject.clear();
        }
        else if (words[0] == "clearScreen") {
            //清除畫面
            glClear(GL_COLOR_BUFFER_BIT);
            glFlush();
        }
        else if (words[0] == "object") {
            //讀obj檔
            string objName = "Mesh/"+words[1];
            Mesh obj(objName);
            cout << obj.triangles.size() << endl;
            //triangles(存哪個verites) Verties(存xyz)
            for (int i = 0; i < obj.triangles.size() / 3; i++) { //幾個三角形
                Triangle = TrianglesMatrix::Triangle(obj.verties[obj.triangles[i * 3 + 0]], obj.verties[obj.triangles[i * 3 + 1]], obj.verties[obj.triangles[i * 3 + 2]]);
                //TM * tri
                Triangle = Triangle * transformMatrix;
                Triangles.push_back(Triangle);
            }
        }
        else if (words[0] == "observer") { //epx epy epz COIx COIy COIz Tilt Hither Yon Hav
            //MVP Matrix
            //EM (v)
            Vector3 view(stof(words[1]), stof(words[2]), stof(words[3]));
            Vector3 coi(stof(words[4]), stof(words[5]), stof(words[6]));
            Vector3 forward = (coi - view).Normalized();
            eyev = forward;
            Vector3 temp(0, 1.0, 0);
            Vector3 right = temp.Cross(forward).Normalized();
            Vector3 up = forward.Cross(right).Normalized();
            Matrix4 Mirrorx = Matrix4::Identity();
            Mirrorx.SetXAxis(Vector3(-1.0, 0.0, 0.0));
            Matrix4 GRM = Matrix4::GRM(right, up, forward);
            Matrix4 transEye = Matrix4::Trans(Vector3(-stof(words[1]), -stof(words[2]), -stof(words[3])));
            float Tilt = stof(words[7]) * PI / 180;
            Matrix4 tilt = Matrix4::RotZ(Tilt);
            EM = tilt * (Mirrorx * (GRM * transEye));
            cout << "V" << endl;
            cout << EM << endl;

            //PM (p)
            float Hither = stof(words[8]);
            float Yon = stof(words[9]);
            float FOV = stof(words[10]) * PI / 180;
            PM = Matrix4::PM(FOV, Hither, Yon);
            cout << "P" << endl;
            cout << PM << endl;
        }
        else if (words[0] == "display") {
            glClear(GL_COLOR_BUFFER_BIT);
            glFlush();
            glColor3f(1, 1, 1);
            //乘矩陣畫圖
            //EM * tri
            //PM * tri
            for (int i = 0; i < Triangles.size(); i++) { //幾個三角形
                Triangle = Triangles[i] * EM;
                Triangle = Triangle * PM;
                // Triangle = TrianglesMatrix::PD();
                DisplayTriangles.push_back(Triangle);
            }
            // cout << PM * EM << endl;
            // cout << "origin" << endl;
            // cout << Triangles[0] << endl;
            // Triangle = Triangles[0] * EM;
            // cout << "EM" << endl;
            // cout << Triangle << endl;
            // Triangle = Triangle * PM;
            // cout << "PM" << endl;
            // cout << Triangle << endl;
            // Triangle = TrianglesMatrix::PD();
            // cout << "PD" << endl;
            // cout << Triangle << endl;
            int xmin = (view[0] + 1) * (width / 2);
            int xmax = (view[1] + 1) * (width / 2);
            int ymin = (view[2] + 1) * (height / 2);
            int ymax = (view[3] + 1) * (height / 2);
            drawLines(xmin, ymin, xmax, ymin);
            drawLines(xmax, ymin, xmax, ymax);
            drawLines(xmax, ymax, xmin, ymax);
            drawLines(xmin, ymax, xmin, ymin);
            glColor3f(0, 0.9, 1);
            //映射 [1]vxl [2]vxr [3]vyb [4]vyt
            // cout << DisplayTriangles[0] << endl;
            for (int i = 0; i < DisplayTriangles.size(); i++) {
                //glColor3f(color[i].red, color[i].green, color[i].blue);
                // DisplayTriangles[i] = TrianglesMatrix::View(-1, 1, -1, 1, xmin, xmax, ymin, ymax);
                Vector4 v1 = DisplayTriangles[i].point1();
                Vector4 v2 = DisplayTriangles[i].point2();
                Vector4 v3 = DisplayTriangles[i].point3();
                // v1 = v1.Map(-1, 1, -1, 1, xmin, xmax, ymin, ymax);
                // v2 = v2.Map(-1, 1, -1, 1, xmin, xmax, ymin, ymax);
                // v3 = v3.Map(-1, 1, -1, 1, xmin, xmax, ymin, ymax);
                // drawLines(v1.x, v1.y, v2.x, v2.y);
                // drawLines(v2.x, v2.y, v3.x, v3.y);
                // drawLines(v3.x, v3.y, v1.x, v1.y);
                ClipTriangle.push_back(v1);
                ClipTriangle.push_back(v2);
                ClipTriangle.push_back(v3);
                ClipTriangles.push_back(ClipTriangle);
                ClipTriangle.clear();
                //clip back
                Vector3 cv1 = (DisplayTriangles[i].XAxis() - DisplayTriangles[i].YAxis()).Normalized();
                Vector3 cv2 = (DisplayTriangles[i].ZAxis() - DisplayTriangles[i].YAxis()).Normalized();
                // if (cv1.Dot(cv2) < 0.0 && cv1.Dot(cv2) > -1.0) continue;
                float angle = (cv1.Cross(cv2)).Angle(eyev) * 180 / PI;
                if (angle > 90 && angle < 180) continue;
                //3D Clipping
                clip3D(i, ClipTriangles[i].size(), 1);
                clip3D(i, ClipTriangles[i].size(), 2);
                clip3D(i, ClipTriangles[i].size(), 3);
                clip3D(i, ClipTriangles[i].size(), 4);
                clip3D(i, ClipTriangles[i].size(), 5);
                clip3D(i, ClipTriangles[i].size(), 6);
                for (int j = 0; j < ClipTriangles[i].size(); j++) {
                    //PD
                    ClipTriangles[i][j] = ClipTriangles[i][j] / ClipTriangles[i][j].w;
                    //View
                    ClipTriangles[i][j] = ClipTriangles[i][j].Map(-1, 1, -1, 1, xmin, xmax, ymin, ymax);
                }
                // clip  view 邊框逆時針輸入
                clip(i, ClipTriangles[i].size(), xmin, ymin, xmin, ymax);
                clip(i, ClipTriangles[i].size(), xmin, ymax, xmax, ymax);
                clip(i, ClipTriangles[i].size(), xmax, ymax, xmax, ymin);
                clip(i, ClipTriangles[i].size(), xmax, ymin, xmin, ymin);
                if (noDraw) {
                    noDraw = 0;
                }
                else {
                    for (int k = 0; k < ClipTriangles[i].size(); k++) {
                        int l = (k + 1) % ClipTriangles[i].size();
                        drawLines(round(ClipTriangles[i][k].x), round(ClipTriangles[i][k].y), round(ClipTriangles[i][l].x), round(ClipTriangles[i][l].y));
                    }
                }
            }
            // cout << DisplayTriangles[0] << endl;
            DisplayTriangles.clear();
            ClipTriangles.clear();
            glFlush();
            PAUSE;
        }
        else if (words[0] == "end") {
            exit(0);
        }
        words.clear();
    }
    ifs.close();
}

void display() {
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glPointSize(1);
    glFlush();
    readFile();
}
         
int main(int argc, char* argv[]) {
    glutInit(&argc, argv);
    if (argv[1] != NULL) {
        ifs.open(argv[1]);
        if (!ifs.is_open()) {
            cout << "Failed to open file.\n";
        }
        string wh;
        getline(ifs, wh);
        width = stoi(wh.substr(0, wh.find(" ")));
        height = stoi(wh.substr(wh.find(" ") + 1, wh.length() + 1));
        cout << "w:" << width << " h:" << height << endl;
    }
    PAUSE
    glutInitDisplayMode(GLUT_RGBA | GLUT_SINGLE);
    glutInitWindowSize(width, height);
    glutInitWindowPosition(100, 100);
    window = glutCreateWindow("Your First GLUT  Window!");
    //glutSwapBuffers();
    glutDisplayFunc(display);
    // 更新
    glutTimerFunc(0, timer, 0);
    gluOrtho2D(0, width, 0, height);
    glutMainLoop();

    return 0;
}

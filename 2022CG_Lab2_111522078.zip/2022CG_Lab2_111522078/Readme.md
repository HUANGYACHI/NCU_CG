# Readme

## 使用 Linux

### 執行
1. 在 `2022CG_Lab2_111522078` 資料夾裡開終端機
2. 輸入 `./HW2 lab2X.in` 執行程式
